<?php
require_once('conn.php');
class Hotel extends Connect
{
	
	public function gethotelDetails($var)
	{
		
		$x=new Connect;
		$sql="Select * from hotel where hotel_id='$var'";
		$c= $x->getconnect();
		$result = $c->query($sql);
		$a=array();
		if ($result->num_rows > 0) 
	   {
       while($row = $result->fetch_array()) 
	   {
		
				$a[]=array($row[0],$row[1],$row[2],$row[3],$row[4]);
		}
       }
	  // var_dump($a);
		return $a;
    }
	public function showHotelByDest($var)
	{
		
		$x=new Connect;
		$sql="Select * from hotel where dest_name='$var'";
		$c= $x->getconnect();
		$result = $c->query($sql);
		$a=array();
		if ($result->num_rows > 0) 
	   {
       while($row = $result->fetch_array()) 
	   {
		
				$a[]=array($row[0],$row[1],$row[2],$row[3],$row[4]);
		}
       }
	  // var_dump($a);
		return $a;
    }

	
}	 
?>