<?php
require_once('conn.php');
require_once('classhotel.php');
require_once('classvehicle.php');
class Package extends Connect
{
	
	public function displayPackageDetails($destname,$price)
	{
		
		$x= new Connect;
        $c=$x->getconnect();
		$var=0;
		$sql;
		if($destname!="" && $price!="" && !$var)
		{
		$sql="select * from package where dest_name='$destname' and price<$price order by price asc";
	    $var=1;
		}
		else if($destname && !$var)
		{
		    $sql="select * from package where dest_name='$destname' order by price asc";
			$var=1;
		}
		else if($price)
		{
			$sql="select * from package where price<$price order by price asc";
		     $var=1;
		}
		else if($destname=="" && $price=="" && !$var)
		{
			 echo "<script type='text/javascript'>alert('Enter some valid choices');</script>";
		         include('index1.php');
		}
			$packarray=array();
			$result=$c->query($sql);
		    if($result->num_rows>0)
			{
			  while($row=$result->fetch_array())
		     {
			  $packarray[]=array($row[0],$row[1],$row[2],$row[3],$row[4],$row[5],$row[6],$row[7],$row[8],$row[9]);
			  }
			   return array($packarray,count($packarray));
		   }
			else
		   {
			   echo "<script type='text/javascript'>alert('sorry!!!! no package available..for your choices');</script>";
		       //include('index1.php');
		       echo "<script>window.open('index1.php','_self')</script>";
		   }
		   
	}
	public function getoffer()
	  {
		  
		$x= new Connect;
        $c=$x->getconnect();
		$date = date('Y-m-d');
		$day_before = date( 'Y-m-d', strtotime( $date . ' -1 day' ) );
		$sql= "select * from package where date(time_of_pack) = '$day_before'";
		$packarray=array();
		if($res=($c->query($sql)))
		{ 
			while($row= $res->fetch_array())
			{
				$packarray[]=array($row[0],$row[1],$row[2],$row[3],$row[4],$row[5],$row[6],$row[7],$row[8],$row[9]);
			}
		}
		 return array($packarray,count($packarray));
	  }	
	  public function getpackage_room($var)
	  {
		  $x= new Connect;
          $c=$x->getconnect();
		  $sql="select * from package_room where package_id='$var';";
		  if($result=($c->query($sql)))
		{ 
			while($row1= $result->fetch_array())
			{
				$packroom[]=array($row1[0],$row1[1],$row1[2],$row1[3]);
			}
			
			return $packroom;
			
		}
	  }
	  public function checkpackage($pid,$hid,$vid,$days,$nov,$date,$s_count,$d_count,$m_count)
	  {
		  $x= new Connect;
          $c=$x->getconnect();
		  $hotelobj=new Hotel;
		  $vehicleobj=new Vehicle;
		  if($s_count)
		  {
		  $checkhotel=$hotelobj->getAvailability($hid,$date,$days,$s_count,$dest,$price);
		  }
		  if($d_count)
		  {
			  $checkhotel=$hotelobj->getAvailability($hid,$date,$days,$d_count,$dest,$price);
		  }
		  if($m_count)
		  {
			  $checkhotel=$hotelobj->getAvailability($hid,$date,$days,$d_count,$dest,$price);
		  }
		  $checkvehicle=$vehicleobj->getAvailability($vid,$date,$days,$number,$dest,$price);
	  }
	  
	  public function deletepackage($var,$dest)
	  {
		  $x= new Connect;
          $c=$x->getconnect();
		  if($c->query("delete from package where package_id='$var';"))
		  {
			  if($c->query("delete from package_room where package_id='$var';"))
			  {
				  $sql="select package_id from package where dest_name='$dest'";
				  if($res=$c->query($sql))
				  {
					     echo "<script type='text/javascript'>alert('package succesfully deleted');</script>";
				          include('admin.php');
				  }
					  
				}
		  }
	  }
	  public function bookpackage()
	  {
		  
	  }
	
}
if(isset($_GET['delete']))
{
$obj=new Package;
$packid=$_GET['packid'];
$dest=$_GET['destination'];
$obj->deletepackage($packid,$dest);
}
if(isset($_GET['book']))
{
$obj=new Package;
$obj->checkpackage();
}
$obj=new Package;
$obj->getoffer();

?>