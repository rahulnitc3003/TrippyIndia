<?php
require_once('conn.php');
require_once('classdest.php');
date_default_timezone_set('UTC');

class Admin extends Connect{
	private $email_id;
	private $password;
    public function addpackage()
{
   $x=new Connect;
   $c= $x->getconnect();
   $var=$_POST['destname'];
   if($var==='other')	
  {
	$destid=rand(1,9999999);
	$file_get=$_FILES['foto']['name'];
    $tmp=$_FILES['foto']['tmp_name'];
    $file_to_saved="images/".$file_get;
   move_uploaded_file($tmp,$file_to_saved);
	$destobj= new Destination;
	$dest=$_POST['destname1'];
	$resu=$destobj->checkdest($_POST['destname1']);
	//echo $resu;
	if($resu)
	{
		$res=$destobj->insertdest($destid,$_POST['destname1']);
	}
		
}
}
public function checkadmin()
	{
        $x=new connect;
		$sql="Select * from  Admin";
		$c= $x->getconnect();
		$result = $c->query($sql);
		if ($result->num_rows > 0) 
	   {
       while($row = $result->fetch_assoc()) 
	   {
       
	   if(($_POST['Username']===$row['admin_id']) && ($_POST['password']===$row['password']))
	   { 
         // $_SESSION['id']=$_POST['Username'];
		   header('location:admin.php');
		   
	   }
	    else 
	   {
		// echo " <script> window.alert('Login Failed')</script>";
		 echo "<script type='text/javascript'>alert('Login Failed');</script>";
		   header('location:login.html');
        //echo "Invalid id and password";
	   }
	   }
	   }
    }
	
}
//echo $_POST['add'];
$obj=new Admin();
if(isset($_POST['submit']))
{

$obj->checkadmin();
}
else if(isset($_POST['add']))
{

$obj->addpackage();
}
 ?>