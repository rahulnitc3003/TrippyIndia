<?php
 
echo $_GET['d'];
echo $_GET['akshi'];
?>