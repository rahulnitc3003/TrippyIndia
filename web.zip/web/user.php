<?php

include_once('conn.php');

class User extends connect
{

   public function CustomHotel($var)
   {
 	   $x= new Connect;
     $c=$x->getconnect();
    
  	 $sc = $var['noofsingle'];
 	   $dc = $var['noofdouble'];
 	   $mc = $var['noofmini'];
 	   $hn = $var['hotelname'];
 	   $did = $var['did'];        #destination 
 	 
 	   $pr = array();             #price of different types of rooms
 	 
     $sql  = "select h.hotel_id,price_room_day from hotel h,hotel_room hr where h.hotel_id=hr.hotel_id and dest_name='$did' and hotel_name='$hn' and room_type='single'";

     
     $result = $c->query($sql);
		 		 	   
     if($result->num_rows>0)
	   {
		
	     while($row=$result->fetch_array())
	    {
         $pr[0] = $row['price_room_day'];
               
       }
     }

      $sql1  = "select h.hotel_id,price_room_day from hotel h,hotel_room hr where h.hotel_id=hr.hotel_id and dest_name='$did' and hotel_name='$hn' and room_type='double'";

     
     $result = $c->query($sql1);
		 		 	   
	   if($result->num_rows>0)
	   {
	  	
	     while($row=$result->fetch_array())
	     {
         $pr[1] = $row['price_room_day'];
                  
       }
     }
        
      $sql3  = "select h.hotel_id,price_room_day from hotel h,hotel_room hr where h.hotel_id=hr.hotel_id and dest_name='$did' and hotel_name='$hn' and room_type='minisuite'";

     
      $result = $c->query($sql3);
		 		 	   
		  if($result->num_rows>0)
		  {
		  	
		      while($row=$result->fetch_array())
		      {
             $pr[2] = $row['price_room_day'];
                  
           }
      }

         


         $hoteltotalprice = ($sc * $pr[0])+($dc * $pr[1])+($mc * $pr[2]);
         
         #echo "<br><br>hotelperdayprice= ".$hoteltotalprice."<br><br>";        
		     return $hoteltotalprice;            

   }

   public function CustomVehicle($var){



   	 $x= new Connect;
     $c=$x->getconnect();
    
  	 $vtype = $var['vtype']; #vehicle type
     $nov = $var['nov'];     #no. of vehicle 
  	 $did = $var['did'];	 
  	 $sql  = "select price_day from vehicle where vehicle_type='$vtype' and dest_name='$did'";
     $prv = 0;
     
     $result = $c->query($sql);
		 		 	   
     if($result->num_rows>0)
	 {
		
	   while($row=$result->fetch_array())
	   {
         $prv = $row['price_day'];
               
       }
     }

    
   
     $vehicletotalprice = $prv;
         
     #echo "<br><br>vehicletotalprice= ".$vehicletotalprice."<br><br>";        
	 return $vehicletotalprice;            
   }
  

  public function getNoDaysInPkg($var)
  {
    $pid = $var;
    
    $x = new Connect;
    $c = $x->getconnect();
    $prv = 0;
    $sql = "select durationday from package where package_id = '$pid'";
    
    $result = $c->query($sql);

     if($result->num_rows>0)
	 {
		
	   while($row=$result->fetch_array())
	   {
         $prv = $row['durationday'];
               
       }
     }
     #echo "<br><br>durationday= ".$prv."<br><br>";
     return $prv;
  }


  public function getVehiclePriceInPkg($var)
  {
    $pid = $var;
    
    $x = new Connect;
    $c = $x->getconnect();
    $prv = 0;
    $sql = "select price_day from vehicle,package where vehicle.vehicle_id=package.vehicle_id and package_id = '$pid'";
    
    $result = $c->query($sql);

     if($result->num_rows>0)
	 {
		
	   while($row=$result->fetch_array())
	   {
         $prv = $row['price_day'];
               
       }
     }
    #echo "<br><br>price_day= ".$prv."<br><br>";
     return $prv;
  }  
}