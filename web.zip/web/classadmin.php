<?php
session_start();
?>
<?php
require_once('conn.php');
date_default_timezone_set('UTC');

class Admin extends Connect{
	private $email_id;
	private $password;
    public function addpackage()
{
   $x=new Connect;
   $c= $x->getconnect();
   $var=$_POST['destname'];
    //echo $var;
  //echo $_POST['destname1'];
  if($var==='other')	
  {
	$destid=rand(1,9999999);
	$file_get=$_FILES['foto']['name'];
    $tmp=$_FILES['foto']['tmp_name'];
    $file_to_saved="images/".$file_get;
    move_uploaded_file($tmp,$file_to_saved);
	$resu=$c->query("select dest_id from destination where dest_name='".$_POST['destname1']."';");
	if($resu->num_rows==0)		
	{
		$sql="insert into destination values('$destid','".$_POST['destname1']."');";
	    if($c->query($sql))
	    {
			 $hotelid=rand(1,9999999);
			 //echo $_POST['hotel'];
			 //echo $_POST['hcon'];
			// echo $_POST['snr'];
			 $sql1="insert into hotel values('$hotelid','".$_POST['destname1']."','".$_POST['hotel']."','".$_POST['hoteltype']."','".$_POST['hcon']."');";
			 $res=$c->query($sql1);
			 if($res)
			 {
				if(($_POST['snr']) && ($_POST['dnr']) && ($_POST['mns']))
				{
					$sql2="insert into hotel_room values('$hotelid','single','".$_POST['psnr']."','".$_POST['snr']."')
					,('$hotelid','double','".$_POST['pdnr']."','".$_POST['dnr']."'),
					('$hotelid','minisuite','".$_POST['pmns']."','".$_POST['mns']."');";
					if($c->query($sql2))
					{
						if(($_POST['tsnr']) && ($_POST['tsenr']) && ($_POST['tsuv']))
					    {
						$vehicleid1=rand(5,600);
					    $vehicleid2=rand(700,1000);
						$vehicleid3=rand(1000,2000);
						$sql3="insert into vehicle values('$vehicleid1','".$_POST['destname1']."','scooty','2','".$_POST['ctsnr']."','".$_POST['tsnr']."')
						,('$vehicleid2','".$_POST['destname1']."','sedan','5','".$_POST['ctsenr']."','".$_POST['tsenr']."'),
						('$vehicleid3','".$_POST['destname1']."','SUV','7','".$_POST['ctsuv']."','".$_POST['tsuv']."');";
						if($c->query($sql3))
						{
							$packageid=rand(10000,400000);
							$typrm=$_POST['typeroom'];
							$s=$d=$m=0;
							
							for($i=0;$i<count($typrm);$i++)
							{
								 if($typrm[$i]==='single')
								{     $s=1; }
								if($typrm[$i]==='double')
								{     $d=1; }
								if($typrm[$i]==='minisuite')
							    {	$m=1;   }
							}
							$sql4="insert into package_room values('$packageid','$s','$d','$m');";
							if($c->query($sql4))
							{
								$priceroom=0;
								for($i=0;$i<count($typrm);$i++)
								{
									$res=$c->query("Select price_room_day from hotel_room where room_type='$typrm[$i]';");
									if($row=$res->fetch_assoc())
									{
										
										$priceroom=$priceroom+$row['price_room_day'];
									}
								}
								$pricevehicle=0;
								$res=$c->query("Select price_day from vehicle where dest_name='".$_POST['destname1']."' and vehicle_type='".$_POST['typevehicle']."';");
							   if($row=$res->fetch_assoc())
									{
									   $pricevehicle+=$row['price_day'];
									}
									$as=$_POST['day'];
								$price=((($priceroom +$pricevehicle)*$as)+'500');
							}
							$res=$c->query("select vehicle_id from vehicle where dest_name='".$_POST['destname1']."' and vehicle_type='".$_POST['typevehicle']."';");
							$vehicleid=0;
							if($row=$res->fetch_assoc())
									{
										$vehicleid=$row['vehicle_id'];
									}
									$date= date('Y-m-d H:i:s');
							        $sql6="insert into package values('$packageid','".$_POST['destname1']."','$hotelid','$vehicleid','1','$price','".$_POST['day']."','".$_POST['night']."','$file_to_saved','$date');";
							//      echo $sql6;
							       if($c->query($sql6))
							      {
								     
								     echo "<script type='text/javascript'>alert('Package successfully added');</script>";
				                     include('adminadd.php');
							      }
						}
					  }
					}
				}					
			 }
		}
	}  
	       else
	       {
				echo "<script type='text/javascript'>alert('Destination already exists');</script>";
				                  include('adminadd.php');
				
			}
  }
  else
  {
	  $var2=$_POST['ehname'];
	  $packageid=rand(10000,400000);
	  $file_get=$_FILES['foto1']['name'];
      $tmp=$_FILES['foto1']['tmp_name'];
      $file_to_saved="images/".$file_get;
	  //echo $var2;
      move_uploaded_file($tmp,$file_to_saved);
	  if($var2==='hother')
		{
			$resu=$c->query("select hotel_id from hotel where hotel_name='".$_POST['ehname']."';");
			if($resu->num_rows==0)		
	       { 
	            //echo "m there";
				//echo $_POST['destname'];
			   $hotelid=rand(1,999999);
			   //$res1=$c->query("select dest_id from destination where dest_name='$var';");
			   //if($row = $res1->fetch_assoc())
			  // {
				  // echo "coming in 1";
				   //$destid=$row['dest_id'];
				   $sql1="insert into hotel values('$hotelid','$var','".$_POST['hotel1']."','".$_POST['hoteltype1']."','".$_POST['hcon1']."');";
				   if($c->query($sql1))
				   {
					   if(($_POST['snr1']) && ($_POST['dnr1']) && ($_POST['mns1']))
				      {
					  $sql2="insert into hotel_room values('$hotelid','single','".$_POST['psnr1']."','".$_POST['snr1']."'),
					    ('$hotelid','double','".$_POST['pdnr1']."','".$_POST['dnr1']."'),
					    ('$hotelid','minisuite','".$_POST['pmns1']."','".$_POST['mns1']."');";
						if($c->query($sql2))
					  {
						
						    $typrm=$_POST['typeroom1'];
							$s=$d=$m=0;
							
							for($i=0;$i<count($typrm);$i++)
							{
								if($typrm[$i]==='single')
								{     $s=1;  }
								if($typrm[$i]==='double')
								{     $d=1;  }
								if($typrm[$i]==='minisuite')
							    {	$m=1;   }
							}


							$sql4="insert into package_room values('$packageid','$s','$d','$m');";
							if($c->query($sql4))
							{
								$priceroom=0;
								for($i=0;$i<count($typrm);$i++)
								{
									$res=$c->query("Select price_room_day from hotel_room where room_type='$typrm[$i]';");
									if($row=$res->fetch_assoc())
									{
										$priceroom=$priceroom+$row['price_room_day'];
									}
								}
								$pricevehicle=0;
								
								$res=$c->query("Select price_day from vehicle where dest_name='$var' and vehicle_type='".$_POST['typevehicle1']."';");
							   if($row=$res->fetch_assoc())
									{
										$pricevehicle+=$row['price_day'];
									}
									$as=$_POST['day1'];
								   $price=((($priceroom +$pricevehicle)*$as)+'500');
								   $vehicleid=0;
								   $res=$c->query("select vehicle_id from vehicle where dest_name='$var' and vehicle_type='".$_POST['typevehicle1']."';");
							       
							       if($row=$res->fetch_assoc())
									{
										$vehicleid=$row['vehicle_id'];
									}
							$date= date('Y-m-d H:i:s');
							$sql6="insert into package values('$packageid','$var','$hotelid',
							'$vehicleid','1','$price','".$_POST['day1']."','".$_POST['night1']."','$file_to_saved','$date');";
                           //echo $sql6;
							if($c->query($sql6))
							{
								 echo "<script type='text/javascript'>alert('Package successfully added');</script>";
				                 include('adminadd.php');
							}
							}
						
							
							
						
						}
					   }
				     }
			  // }
		   }
		   else
		   {
			   echo "<script type='text/javascript'>alert('Hotel already exists in destination');</script>";
			   include('adminadd.php');
			}
		}
		else
		{
			$file_get=$_FILES['foto2']['name'];
            $tmp=$_FILES['foto2']['tmp_name'];
            $file_to_saved="images/".$file_get;
            move_uploaded_file($tmp,$file_to_saved);
			$resu=$c->query("select hotel_id from hotel where hotel_name='$var2';");
			
			if($row=$resu->fetch_assoc())
			{
				
				$hotelid=$row['hotel_id'];
				
			}
			
		     echo $_POST['typevehicle2'];
			 $vehicleid=0; 
			$res1=$c->query("select vehicle_id from vehicle where vehicle_name='".$_POST['typevehicle2']."';");
			if($row1=$res1->fetch_assoc())
			{
				$vehicleid=$row1['vehicle_id'];
				//echo $vehicleid;
			}
			
			                $typrm=$_POST['typeroom2'];
							$s=$d=$m=0;
							
							for($i=0;$i<count($typrm);$i++)
							{
								 
								if($typrm[$i]==='single')
								{     $s=1; 
							    }
								if($typrm[$i]==='double')
								{     $d=1;
						        }
								if($typrm[$i]==='minisuite')
							    {	$m=1;
							      
         						}
							}
							$sql1="insert into package_room values('$packageid','$s','$d','$m');";
							if($c->query($sql1))
							{
								$priceroom=0;
								for($i=0;$i<count($typrm);$i++)
								{
									$res=$c->query("Select price_room_day from hotel_room where room_type='$typrm[$i]';");
									if($row=$res->fetch_assoc())
									{
										$priceroom=$priceroom+$row['price_room_day'];
									}
								}
								$pricevehicle=0;
								$res=$c->query("Select price_day from vehicle where dest_name='$var' and vehicle_type='".$_POST['typevehicle2']."';");
							   if($row=$res->fetch_assoc())
									{
										$pricevehicle+=$row['price_day'];
									}
									$as=$_POST['day'];
								$price=((($priceroom +$pricevehicle)*$as)+'500');
								$date= date('Y-m-d H:i:s');
								$sql2="insert into package values('$packageid','$var','$hotelid',
							    '$vehicleid','1','$price','".$_POST['day2']."','".$_POST['night2']."','$file_to_saved','$date');";
							if($c->query($sql2))
							 {
							     echo "<script type='text/javascript'>alert('Package successfully added');</script>";
				                 include('adminadd.php');
							  }
						  }
		}
  }
}
public function checkadmin()
	{
        $x=new connect;
		$sql="Select * from  Admin";
		$c= $x->getconnect();
		$result = $c->query($sql);
		$_SESSION['username']=$_POST['Username'];
		if ($result->num_rows > 0) 
	   {
       while($row = $result->fetch_assoc()) 
	   {
       
	   if(($_POST['Username']===$row['admin_id']) && ($_POST['password']===$row['password']))
	   { 
         // $_SESSION['id']=$_POST['Username'];
		   header('location:admin.php');
		   
	   }
	    else 
	   {
		// echo " <script> window.alert('Login Failed')</script>";
		 echo "<script type='text/javascript'>alert('Login Failed');</script>";
		   header('location:login.html');
        //echo "Invalid id and password";
	   }
	   }
	   }
    }
	
}
//echo $_POST['add'];
$obj=new Admin();
if(isset($_POST['submit']))
{

$obj->checkadmin();
}
else if(isset($_POST['add']))
{

$obj->addpackage();
}
 ?>