<?php

class Connect{
/* for connection */
public $servername;
public $username;
public $pass;
public $dbname;
public  function getconnect()
{
	
 $servername = "localhost";
 $username = "root";
 $pass = "";
 $dbname="saamp";
 $conn=new mysqli($servername, $username, $pass,$dbname);
    if ($conn->connect_error) 
	{
    die("Connection failed: " . $conn->connect_error);
    } 
   
return $conn;
}
}



?>