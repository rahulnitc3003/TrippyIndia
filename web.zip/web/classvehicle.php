<?php
require_once('conn.php');
class Vehicle extends Connect
{
	
	public function getvehicleDetails($var)
	{
		$x=new Connect;
		$sql="Select * from vehicle where vehicle_id='$var'";
		$c= $x->getconnect();
		$result = $c->query($sql);
		$a=array();
		if ($result->num_rows > 0) 
	   {
       while($row = $result->fetch_array()) 
	   {
	       $a[]=array($row[0],$row[1],$row[2],$row[3],$row[4],$row[5]);
		}
       }
		return $a;
    }
	public function getAvailability($vid,$date,$number,$days)
	{
		$x=new Connect;
		$c=$x->getconnect();
		if($res=$c->query("Select * from book_ where vehicle_id='$vid';"))
		{
			if($c->$res->num_rows>0)
			{
				//if($res1=$c->query("select "))
			}
			else
			{
				return 1;
			}
		}
		
		
	}	
    
	
}	 
?>