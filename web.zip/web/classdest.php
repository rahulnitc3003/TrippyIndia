<?php
require_once('conn.php');
class Destination extends Connect
{
	
	public function getdest()
	{
		
		$x=new Connect;
		$sql="Select dest_name from destination";
		$c= $x->getconnect();
		$result = $c->query($sql);
		if ($result->num_rows > 0) 
	   {
       while($row = $result->fetch_assoc()) 
	   {
		$a[]=$row['dest_name'];
		}
	  }
		return $a;
    }
	public function checkdest($dest)
	{
		$x=new Connect;
		$c = $x->getconnect();
		echo $dest;
		$res=$c->query("select dest_id from destination where dest_name= $dest;");
		if($res->num_rows==0)
		return	1;
			else return 0;
	}
	public function insertdest($destid,$dest)
	{
		
		
		$sql="insert into destination values('$destid','$dest');";
		 echo $sql;
		$x=new Connect;
		$c = $x->getconnect();
		//if($c->query($sql))
			//return 1; 
	}
}	

?>