<?php
session_start();

//Include Google client library 
include_once 'src/Google_Client.php';
include_once 'src/contrib/Google_Oauth2Service.php';

/*
 * Configuration and setup Google API
 */
$clientId = '618451532351-4eiunvv16f5785siq8u60rqoanc6adll.apps.googleusercontent.com'; //Google client ID
$clientSecret = 'wjJAVt5_lmEA4mI1G234O8VR'; //Google client secret
$redirectURL = 'https://vacxcursion.000webhostapp.com/index1.php'; //Callback URL

//Call Google API
$gClient = new Google_Client();
$gClient->setApplicationName('Login to Vacxcursion');
$gClient->setClientId($clientId);
$gClient->setClientSecret($clientSecret);
$gClient->setRedirectUri($redirectURL);

$google_oauthV2 = new Google_Oauth2Service($gClient);
?>
